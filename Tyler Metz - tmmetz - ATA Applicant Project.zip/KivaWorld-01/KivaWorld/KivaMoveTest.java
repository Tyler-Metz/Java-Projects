import edu.duke.Point;
/**
 * Main module for verifying kiva gamestate in terms of location, facing direction, carrying, and dropping pods.
 */
public class KivaMoveTest {
    /**
     * Main module for running and moving the kiva bot.
     * Responsible for throwing exceptions, properly setting and getting fields, and moving kiva.
     */
    class Kiva extends KivaMoveTest{
        // field made for Kiva(FloorMap)
        private FloorMap map;
        
        // fields that are set in move(KivaCommand)
        private Point pos;
        private FacingDirection dir;
        private boolean carrying;
        private boolean dropped; 
        private long motorLifetime;
        
        /**
         * @param passedMap respresents the map kiva will be ran on, which is the 
         * floormap object generated from defaultMapGenerator.
         * @see FloorMap
         */
        public Kiva(FloorMap passedMap){
            map = passedMap;
        }

        /**
         * Sets the pos, dir, carrying, dropped, and motorLifetime fields.
         * For more information, see inline comments.
         *
         * @param command given enum to move up, right, down, or left.
         * @see KivaCommand
         */
        public void move(KivaCommand command){
            // Initial instance variables used to determine carrying and dropped fields and exceptions.
            FloorMapObject objAtPos;
            FloorMapObject objAtNewPos;
            
            // Sets inital pos of map passed in on kiva creation and inital direction facing up.
            if (pos == null){
            pos = map.getInitialKivaLocation();
            dir = FacingDirection.UP;
            }
            
            // Sets object at current position
            objAtPos = map.getObjectAtLocation(pos);
            
            // Sets FacingDirection to field dir
            switch(command){
                case TURN_LEFT:
                    switch (dir){
                        case UP:
                            dir = FacingDirection.LEFT;
                            break;
                        case RIGHT:
                            dir = FacingDirection.UP;
                            break;
                        case DOWN:
                            dir = FacingDirection.RIGHT;
                            break;
                        case LEFT:
                            dir = FacingDirection.DOWN;
                            break;
                    }   
                    break;
                case TURN_RIGHT:
                    switch (dir){
                        case UP:
                            dir = FacingDirection.RIGHT;
                            break;
                        case RIGHT:
                            dir = FacingDirection.DOWN;
                            break;
                        case DOWN:
                            dir = FacingDirection.LEFT;
                            break;
                        case LEFT:
                            dir = FacingDirection.UP;
                            break;
                    }   
                    break;
                case TAKE:
                        if (objAtPos.toChar() == 'P' && carrying != true){
                            carrying = true;
                        } else {
                            throw new NoPodException(String.format("There is no POD available at %s to pick up! Try again!", pos));
                        }
                    break;
                case DROP:
                        if (carrying == true && objAtPos.toChar() == 'D'){
                            dropped = true;
                            carrying = false;
                        } else if (carrying == true && objAtPos.toChar() != 'D'){
                            throw new IllegalDropZoneException(String.format("POD can only be dropped inside a Drop Zone, not %s! Try again!", pos));
                        } else if (carrying != true && objAtPos.toChar() == 'D'){
                            throw new IllegalMoveException("There is no POD available to drop in the Drop Zone! Try again!");
                        }else if (carrying != true){
                            throw new IllegalMoveException(String.format("There is no POD available to drop at %s! Try again!", pos));
                        } 
                    break;
                default:
                    System.out.println("No conditionals met in move() cases");
                    break;
            }

            // Set delta cords from dir - CLOCKWISE (0, -1), (1, 0), (0, 1), (-1, 0)
            Point delta = dir.getDelta();
            if (command == KivaCommand.FORWARD){
                // Gets destination coords
                int deltaX = delta.getX();
                int deltaY = delta.getY();

                // Gets current coords
                int currentLocX = pos.getX();
                int currentLocY = pos.getY();
                System.out.printf("Current Location coords: (%d,%d)\n", currentLocX, currentLocY);

                // Sets new position to instance variable
                int newY = currentLocY + deltaY;
                int newX = currentLocX + deltaX;
                Point newPos = new Point(newX, newY);
                System.out.printf("Moving %s to Location coords: %s\n", dir, newPos);
                
                // Throws move exception if moving outside the map
                if (newX < 0 || newX > map.getMaxColNum() ||
                    newY < 0 || newY > map.getMaxRowNum()){
                        throw new IllegalMoveException(String.format("Out of bounds is off-limits at %s! Try again!", newPos));
                    }
                
                // If newPos is not outside the map, will get object at location trying to move to.
                objAtNewPos = map.getObjectAtLocation(newPos);
                
                // Throws move exception if moving on an obstacle
                if (objAtNewPos.toChar() == '|'){
                    throw new IllegalMoveException(String.format("Kiva can't go on an %s at %s! Try again!", objAtNewPos.toString(), newPos));
                }
                
                // Throws move exception if moving onto a POD while carrying one.
                if (objAtNewPos.toChar() == 'P' && carrying == true) {
                    throw new IllegalMoveException(String.format("Kiva can't go on a %s at while carrying a POD! Try again!", objAtNewPos.toString(), newPos));
                }
                
                // Sets instance variable "newPos" to the field "pos"
                pos = newPos;
                System.out.println("New position set: " + newPos);
                
                // Increases motorLifetime by 1000 when moving forward
                incrementMotorLifetime();
            }
            else if (command == KivaCommand.TURN_LEFT) {
                System.out.printf("Trying to turn Kiva Bot %s ...\n", command.toString().substring(5));
                
                // Increases motorLifetime by 1000 when turning left is successful
                incrementMotorLifetime();
            }
            else if (command == KivaCommand.TURN_RIGHT) {
                System.out.printf("Trying to turn Kiva Bot %s ...\n", command.toString().substring(5));
                
                // Increases motorLifetime by 1000 when turning right is successful
                incrementMotorLifetime();
            }
            else if (command == KivaCommand.TAKE) {System.out.printf("Trying to %s %s\n", command.toString(), objAtPos);
            }
            else if (command == KivaCommand.DROP) {System.out.printf("Trying to %s POD in %s\n", command.toString(), objAtPos);
            }
            else System.out.println("Trying to do nothing I guess...");

        }

        /**
         * @return current location of the kiva robot according to x and y coords.
         * @see Point
         */
        public Point getCurrentLocation(){
            return pos;
        }

        /**
         * @return the facing direction of the kiva bot.
         * @see FacingDirection
         */
        public FacingDirection getDirectionFacing(){
            return dir;
        }

        /**
         * @return true or false depending on if kiva is currently carrying a pod.
         */
        public boolean isCarryingPod(){
            return carrying;
        }

        /**
         * @return true or false depending on if kiva has succesfully dropped a pod in the dropzone at any given point.
         */
        public boolean isSuccessfullyDropped(){
            return dropped;
        }
        
        /**
         * @return the total time kiva has been running in milliseconds.
         */
        public double getMotorLifetime(){
            return motorLifetime;
        }
        
        /**
         * @return increases the time kiva has been running in milliseconds if turning or moving forward.
         */
        public long incrementMotorLifetime(){
            return motorLifetime += 1000;
        }
    }

    private boolean sameLocation(Point a, Point b) {
        return a.getX() == b.getX() && a.getY() == b.getY();
    }

    public void verifyKivaState(
    String testName,
    Kiva actual,
    Point expectLocation,
    FacingDirection expectDirection,
    boolean expectCarry,
    boolean expectDropped) {

        Point actualLocation = actual.getCurrentLocation();
        if (sameLocation(actualLocation, expectLocation)) {
            System.out.println(
                String.format("%s: current location SUCCESS", testName));
        }
        else {
            System.out.println(
                String.format("%s: current location FAIL!", testName));
            System.out.println(
                String.format("Expected %s, got %s",
                    expectLocation, actualLocation));
        }

        FacingDirection actualDirection = actual.getDirectionFacing();
        if (actualDirection == expectDirection) {
            System.out.println(
                String.format("%s: facing direction SUCCESS", testName));
        }
        else {
            System.out.println(
                String.format("%s: facing direction FAIL!", testName));
            System.out.println(
                String.format("Expected %s, got %s",
                    expectDirection, actualDirection));
        }

        boolean actualCarry = actual.isCarryingPod();
        if (actualCarry == expectCarry) {
            System.out.println(
                String.format("%s: carrying pod SUCCESS", testName));
        }
        else {
            System.out.println(
                String.format("%s: carrying pod FAIL!", testName));
            System.out.println(
                String.format("Expected %s, got %s",
                    expectCarry, actualCarry));
        }

        boolean actualDropped = actual.isSuccessfullyDropped();
        if (actualDropped == expectDropped) {
            System.out.println(
                String.format("%s: successfully dropped SUCCESS", testName));
        }
        else {
            System.out.println(
                String.format("%s: successfully dropped FAIL!", testName));
            System.out.println(
                    String.format("Expected %s, got %s",
                            expectDropped, actualDropped));
        }
    }
}