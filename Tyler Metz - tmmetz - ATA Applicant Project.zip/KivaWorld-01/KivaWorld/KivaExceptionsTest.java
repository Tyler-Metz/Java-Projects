public class KivaExceptionsTest {
    defaultMapGenerator gen = new defaultMapGenerator();

    public void testMoveOutOfBounds() {
        // Make new KivaMoveTest Obj
        KivaMoveTest kivaMoveTest = new KivaMoveTest();
        // Make new Kiva innerObj inside of outerObj KivaMoveTest
        KivaMoveTest.Kiva kiva = kivaMoveTest.new Kiva(gen.defaultMap);
        
        kiva.move(KivaCommand.FORWARD);
        kiva.move(KivaCommand.TURN_LEFT);
        kiva.move(KivaCommand.FORWARD);
        kiva.move(KivaCommand.FORWARD);
        System.out.println("testMoveOutOfBounds: (expect an IllegalMoveException)");
        kiva.move(KivaCommand.FORWARD);

        // This only runs if no exception was thrown
        System.out.println("testMoveOutOfBounds FAIL!");
        System.out.println("Moved outside the FloorMap!");
    }

    public void testMoveOntoObstacles() {
        // Make new KivaMoveTest Obj
        KivaMoveTest kivaMoveTest = new KivaMoveTest();
        // Make new Kiva innerObj inside of outerObj KivaMoveTest
        KivaMoveTest.Kiva kiva = kivaMoveTest.new Kiva(gen.defaultMap);
        
        kiva.move(KivaCommand.FORWARD);
        kiva.move(KivaCommand.TURN_RIGHT);
        kiva.move(KivaCommand.FORWARD);
        kiva.move(KivaCommand.FORWARD);

        System.out.println("IllegalMoveException FAILED: Kiva moved onto Obstacle!");
    }

    public void testMoveOntoPodWhileCarryingIsTrue() {
        // Make new KivaMoveTest Obj
        KivaMoveTest kivaMoveTest = new KivaMoveTest();
        // Make new Kiva innerObj inside of outerObj KivaMoveTest
        KivaMoveTest.Kiva kiva = kivaMoveTest.new Kiva(gen.defaultMap);
        
        kiva.move(KivaCommand.FORWARD);
        kiva.move(KivaCommand.FORWARD);
        kiva.move(KivaCommand.FORWARD);
        kiva.move(KivaCommand.TURN_RIGHT);
        for (int i=0;i < 6;i++){
            kiva.move(KivaCommand.FORWARD);
        }
        kiva.move(KivaCommand.TAKE);
        // Pod picked up...

        // Now - moving off POD location...
        kiva.move(KivaCommand.FORWARD);
        kiva.move(KivaCommand.TURN_RIGHT);
        kiva.move(KivaCommand.TURN_RIGHT);

        // Moving onto POD while carrying is true...
        kiva.move(KivaCommand.FORWARD);

        System.out.println("IllegalMoveException FAILED: Kiva moved onto POD while carrying one!");
    }

    public void testTakePodOnEmptyLocation() {
        // Make new KivaMoveTest Obj
        KivaMoveTest kivaMoveTest = new KivaMoveTest();
        // Make new Kiva innerObj inside of outerObj KivaMoveTest
        KivaMoveTest.Kiva kiva = kivaMoveTest.new Kiva(gen.defaultMap);
        
        kiva.move(KivaCommand.TAKE);
        // Trying to take invalid POD...

        System.out.println("NoPodException FAILED: POD picked up in empty location!");
    }

    public void testDropPodOnEmptyLocation() {
        // Make new KivaMoveTest Obj
        KivaMoveTest kivaMoveTest = new KivaMoveTest();
        // Make new Kiva innerObj inside of outerObj KivaMoveTest
        KivaMoveTest.Kiva kiva = kivaMoveTest.new Kiva(gen.defaultMap);
        
        kiva.move(KivaCommand.FORWARD);
        kiva.move(KivaCommand.FORWARD);
        kiva.move(KivaCommand.FORWARD);
        kiva.move(KivaCommand.TURN_RIGHT);
        for (int i=0;i < 6;i++){
            kiva.move(KivaCommand.FORWARD);
        }
        kiva.move(KivaCommand.TAKE);
        // Pod picked up...

        kiva.move(KivaCommand.FORWARD);
        kiva.move(KivaCommand.DROP);
        // Trying to drop POD without being inside a valid Drop Zone...

        System.out.println("IllegalDropZoneException FAILED: POD dropped in an invalid Drop Zone!");
    }
}
