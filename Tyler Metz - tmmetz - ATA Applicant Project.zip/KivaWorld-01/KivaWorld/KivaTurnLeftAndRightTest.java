import edu.duke.Point;

public class KivaTurnLeftAndRightTest {
    defaultMapGenerator gen = new defaultMapGenerator();
    
    public void testTurnRightFromUp() {
        // Make new KivaMoveTest Obj
        KivaMoveTest kivaMoveTest = new KivaMoveTest();
        // Make new Kiva innerObj inside of outerObj KivaMoveTest
        KivaMoveTest.Kiva kiva = kivaMoveTest.new Kiva(gen.defaultMap);
        
        kiva.move(KivaCommand.TURN_RIGHT);
        kiva.verifyKivaState("testTurnRightFromUp", kiva, new Point(2, 4), FacingDirection.RIGHT, false, false);
    }
    
    public void testTurnRightFromLeft() {
        // Make new KivaMoveTest Obj
        KivaMoveTest kivaMoveTest = new KivaMoveTest();
        // Make new Kiva innerObj inside of outerObj KivaMoveTest
        KivaMoveTest.Kiva kiva = kivaMoveTest.new Kiva(gen.defaultMap);
        
        kiva.move(KivaCommand.TURN_LEFT);
        kiva.move(KivaCommand.TURN_RIGHT);
        kiva.verifyKivaState("testTurnRightFromLeft", kiva, new Point(2, 4), FacingDirection.UP, false, false);
    }
    
    public void testTurnRightFromDown() {
        // Make new KivaMoveTest Obj
        KivaMoveTest kivaMoveTest = new KivaMoveTest();
        // Make new Kiva innerObj inside of outerObj KivaMoveTest
        KivaMoveTest.Kiva kiva = kivaMoveTest.new Kiva(gen.defaultMap);
        
        kiva.move(KivaCommand.TURN_LEFT);
        kiva.move(KivaCommand.TURN_LEFT);
        kiva.move(KivaCommand.TURN_RIGHT);
        kiva.verifyKivaState("testTurnRightFromDown", kiva, new Point(2, 4), FacingDirection.LEFT, false, false);
    }
    
    public void testTurnRightFromRight() {
        // Make new KivaMoveTest Obj
        KivaMoveTest kivaMoveTest = new KivaMoveTest();
        // Make new Kiva innerObj inside of outerObj KivaMoveTest
        KivaMoveTest.Kiva kiva = kivaMoveTest.new Kiva(gen.defaultMap);
        
        kiva.move(KivaCommand.TURN_LEFT);
        kiva.move(KivaCommand.TURN_LEFT);
        kiva.move(KivaCommand.TURN_LEFT);
        kiva.move(KivaCommand.TURN_RIGHT);
        kiva.verifyKivaState("testTurnRightFromRight", kiva, new Point(2, 4), FacingDirection.DOWN, false, false);
    }
}
