import edu.duke.Point;

public class KivaTurnLeftAndForwardTest {
    // Generate Map
    defaultMapGenerator gen = new defaultMapGenerator();
    
    public void testForwardWhileFacingLeft(){
        // Make new KivaMoveTest Obj
        KivaMoveTest kivaMoveTest = new KivaMoveTest();
        // Make new Kiva innerObj inside of outerObj KivaMoveTest
        KivaMoveTest.Kiva kiva = kivaMoveTest.new Kiva(gen.defaultMap);
    
        kiva.move(KivaCommand.TURN_LEFT);
        kiva.move(KivaCommand.FORWARD);
        
        kiva.verifyKivaState("testForwardWhileFacingLeft", 
            kiva, new Point(1, 4), FacingDirection.LEFT, false, false);
    }
    
    public void testForwardWhileFacingDown(){
        // Make new KivaMoveTest Obj
        KivaMoveTest kivaMoveTest = new KivaMoveTest();
        // Make new Kiva innerObj inside of outerObj KivaMoveTest
        KivaMoveTest.Kiva kiva = kivaMoveTest.new Kiva(gen.defaultMap);
        
        kiva.move(KivaCommand.TURN_LEFT);
        kiva.move(KivaCommand.TURN_LEFT);
        kiva.move(KivaCommand.FORWARD);
        
        kiva.verifyKivaState("testForwardWhileFacingDown", 
            kiva, new Point(2, 5), FacingDirection.DOWN, false, false);
    }
    
    public void testForwardWhileFacingRight(){
        // Make new KivaMoveTest Obj
        KivaMoveTest kivaMoveTest = new KivaMoveTest();
        // Make new Kiva innerObj inside of outerObj KivaMoveTest
        KivaMoveTest.Kiva kiva = kivaMoveTest.new Kiva(gen.defaultMap);
        
        kiva.move(KivaCommand.TURN_LEFT);
        kiva.move(KivaCommand.TURN_LEFT);
        kiva.move(KivaCommand.TURN_LEFT);
        kiva.move(KivaCommand.FORWARD);
        
        kiva.verifyKivaState("testForwardWhileFacingRight", 
            kiva, new Point(3, 4), FacingDirection.RIGHT, false, false);
    }
    
    public void testForwardWhileFacingUp(){
        // Make new KivaMoveTest Obj
        KivaMoveTest kivaMoveTest = new KivaMoveTest();
        // Make new Kiva innerObj inside of outerObj KivaMoveTest
        KivaMoveTest.Kiva kiva = kivaMoveTest.new Kiva(gen.defaultMap);
        
        kiva.move(KivaCommand.TURN_LEFT);
        kiva.move(KivaCommand.TURN_LEFT);
        kiva.move(KivaCommand.TURN_LEFT);
        kiva.move(KivaCommand.TURN_LEFT);
        kiva.move(KivaCommand.FORWARD);
        
        kiva.verifyKivaState("testForwardWhileFacingUp", 
            kiva, new Point(2, 3), FacingDirection.UP, false, false);
    }
}
