import edu.duke.FileResource;
import java.util.ArrayList;
import java.util.Arrays;
/**
 * Remote Control Class
 * is responsible for prompting the user to select a map, gets the user input as a string,
 * and converts the string to KivaCommands.
 * This enables the move() method in the Kiva class to run properly. The Kiva class is the inner class of the KivaMoveTest class.
 */
public class RemoteControl {
    KeyboardResource keyboardResource;
    
    /**
     * 
     * Enables user to input thier commands in via console.
     */ 
    public RemoteControl() {
        keyboardResource = new KeyboardResource();
    }
    
    /**
     * 
     * Makes a FileResource object, so the user is prompted with a dialog box to select the map of their liking.
     * Converts actual map into a string line by line.
     * Makes a new FloorMap object and the map is passed through as a parameter gaining a number of methods.
     * 
     * The run method itself doesn't have any parameters and doesn't return anything. Everything is built in, just run it!
     */
    public void run() {
        System.out.println("Please select a map file.");
        FileResource fileResource = new FileResource();
        String inputMap = fileResource.asString();
        FloorMap floorMap = new FloorMap(inputMap);
        System.out.println(floorMap);
        
        // Makes kiva object for the user to use with the map that they selected
        KivaMoveTest kivaMoveTest = new KivaMoveTest();
        KivaMoveTest.Kiva kiva = kivaMoveTest.new Kiva(floorMap);
        
        // Directions for user to enter:
        //      Forward: F
        //      Turn-Left: L
        //      Turn-Right: R
        //      Take: T
        //      Drop: D
        System.out.println("Please enter the directions for the Kiva Robot to take.");
        String directions = keyboardResource.getLine();
        System.out.println("Directions that you typed in: " + directions);
        
        // Convert user commands into an array of KivaCommands
        ArrayList<KivaCommand> convertedCmds = convertToKivaCommands(directions);
        
        // If the field isCarryingPod() is true at any point, wasPodTaken is true, if not, wasPodTaken is false
        boolean wasPodTaken = false;
        
        for (int i = 0; i < convertedCmds.size(); i++){
            
            // Fails session if any moves are done after pod is successfully dropped.
            if (kiva.isSuccessfullyDropped() && convertedCmds.get(i) != KivaCommand.DROP){
                System.out.println("I'm sorry. The Kiva Robot did not pick up the pod and then drop it off in the right place.");
                break;
            }
            
            // Commands the kiva according to the index of convertedCmds
            kiva.move(convertedCmds.get(i));
            
            // Succesfully ends session if pod is succesfully dropped, its the last index in the array, and current command is DROP.
            if (kiva.isSuccessfullyDropped() && convertedCmds.get(i) == KivaCommand.DROP && i == (convertedCmds.size() - 1)){
                System.out.println("Successfully picked up the pod and dropped it off. Thank you!");
            }
            
            // Fails session if its the last index in the array and if pod was never taken.
            else if (i == (convertedCmds.size() - 1) && wasPodTaken == false){
                System.out.println("I'm sorry. The Kiva Robot did not pick up the pod and then drop it off in the right place.");
            }
            
            // Fails session if its the last index in the array and if pod was never succesfully dropped.
            else if (i == (convertedCmds.size() - 1) && kiva.isSuccessfullyDropped() != true){
                System.out.println("I'm sorry. The Kiva Robot did not pick up the pod and then drop it off in the right place.");
            }
            
            // Instance variable to show if pod has been succesfully picked up at any point during the session.
            if (kiva.isCarryingPod()){
                wasPodTaken = true;
            }
        }
        System.out.println("userCmds Array: " + convertedCmds);
        
    }
    
    /**
     * 
     *
     * @param userInput The directions instance variable from run(). This is the string the user has put in the console.
     * @return changes the userInput from a String to an ArrayList of KivaCommands.
     * 
     */
    public static ArrayList<KivaCommand> convertToKivaCommands(String userInput){
        
        //Converts String array into char array
        char[] userInputArr = userInput.toCharArray();
        
        // Makes empty KivaCommand array
        ArrayList<KivaCommand> userCmds = new ArrayList<KivaCommand>();
        
        // Converts char array into KivaCommands, and stores it in the KivaCommand array according to index
        for (int i = 0; i < userInputArr.length; i++){
            switch(userInputArr[i]){
                case 'F':
                    userCmds.add(i, KivaCommand.FORWARD);
                    break;
                case 'L':
                    userCmds.add(i, KivaCommand.TURN_LEFT);
                    break;
                case 'R':
                    userCmds.add(i, KivaCommand.TURN_RIGHT);
                    break;
                case 'T':
                    userCmds.add(i, KivaCommand.TAKE);
                    break;
                case 'D':
                    userCmds.add(i, KivaCommand.DROP);
                    break;
                default:
                    throw new IllegalArgumentException(String.format("Illegal character %c used for input! Try again!", userInputArr[i]));
            }
        }
        
        return userCmds;
    }
}
