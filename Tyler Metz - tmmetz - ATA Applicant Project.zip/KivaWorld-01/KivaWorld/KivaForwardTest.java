import edu.duke.Point;

public class KivaForwardTest {
    // Generate Map
    defaultMapGenerator gen = new defaultMapGenerator();
    
    public void testForwardFromUp() {
        // Make new KivaMoveTest Obj
        KivaMoveTest kivaMoveTest = new KivaMoveTest();
        // Make new Kiva innerObj inside of outerObj KivaMoveTest
        KivaMoveTest.Kiva kiva = kivaMoveTest.new Kiva(gen.defaultMap);
        
        kiva.move(KivaCommand.FORWARD);
        
        kiva.verifyKivaState("testForwardFromUp", 
            kiva, new Point(2, 3), FacingDirection.UP, false, false);
    }
    
    public void testForwardFromRight() {
        // Make new KivaMoveTest Obj
        KivaMoveTest kivaMoveTest = new KivaMoveTest();
        // Make new Kiva innerObj inside of outerObj KivaMoveTest
        KivaMoveTest.Kiva kiva = kivaMoveTest.new Kiva(gen.defaultMap);
        
        kiva.move(KivaCommand.TURN_RIGHT);
        kiva.move(KivaCommand.FORWARD);
        
        kiva.verifyKivaState("testForwardFromRight", 
            kiva, new Point(3, 4), FacingDirection.RIGHT, false, false);
    }
    
    public void testForwardFromDown() {
        // Make new KivaMoveTest Obj
        KivaMoveTest kivaMoveTest = new KivaMoveTest();
        // Make new Kiva innerObj inside of outerObj KivaMoveTest
        KivaMoveTest.Kiva kiva = kivaMoveTest.new Kiva(gen.defaultMap);
        
        kiva.move(KivaCommand.TURN_RIGHT);
        kiva.move(KivaCommand.TURN_RIGHT);
        kiva.move(KivaCommand.FORWARD);
        
        kiva.verifyKivaState("testForwardFromDown", 
            kiva, new Point(2, 5), FacingDirection.DOWN, false, false);
    }
    
    public void testForwardFromLeft() {
        // Make new KivaMoveTest Obj
        KivaMoveTest kivaMoveTest = new KivaMoveTest();
        // Make new Kiva innerObj inside of outerObj KivaMoveTest
        KivaMoveTest.Kiva kiva = kivaMoveTest.new Kiva(gen.defaultMap);
        
        kiva.move(KivaCommand.TURN_LEFT);
        kiva.move(KivaCommand.FORWARD);
        
        kiva.verifyKivaState("testForwardFromLeft", 
            kiva, new Point(1, 4), FacingDirection.LEFT, false, false);
    }
}
