public class KivaMotorLifetimeTester {
    defaultMapGenerator gen = new defaultMapGenerator();
    
    public void getMotorLifetime(){
            // Make new KivaMoveTest Obj
            KivaMoveTest kivaMoveTest = new KivaMoveTest();
            // Make new Kiva innerObj inside of outerObj KivaMoveTest
            KivaMoveTest.Kiva kiva = kivaMoveTest.new Kiva(gen.motorMap);
            
            System.out.println("motorMap Object: " + gen.motorMap);
            System.out.println("motorMap Kiva Location: " + gen.motorMap.getInitialKivaLocation());
            
            System.out.println("Motor Lifetime is at: " + kiva.getMotorLifetime());
            // 0
            
            kiva.move(KivaCommand.TURN_RIGHT);
            System.out.println("getMotorLifetime Started: " + kiva.getMotorLifetime());
            // 1000
            
            kiva.move(KivaCommand.FORWARD);
            System.out.println("getMotorLifetime Started: " + kiva.getMotorLifetime());
            // 2000
            
            kiva.move(KivaCommand.TURN_RIGHT);
            System.out.println("getMotorLifetime Started: " + kiva.getMotorLifetime());
            // 3000
            
            kiva.move(KivaCommand.FORWARD);
            System.out.println("getMotorLifetime Started: " + kiva.getMotorLifetime());
            // 4000
            
            kiva.move(KivaCommand.TAKE);
            System.out.println("getMotorLifetime Started: " + kiva.getMotorLifetime());
            // 4000
            
    }
}
