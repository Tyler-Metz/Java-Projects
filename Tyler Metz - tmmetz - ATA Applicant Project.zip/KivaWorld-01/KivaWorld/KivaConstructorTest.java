import edu.duke.Point;

public class KivaConstructorTest {
    String defaultLayout = "" 
                            + "-------------\n" 
                            + "        P   *\n"
                            + "   **       *\n"
                            + "   **       *\n"
                            + "  K       D *\n"
                            + " * * * * * **\n"
                            + "-------------\n";
                            
    FloorMap defaultMap = new FloorMap(defaultLayout);
    public class Kiva {
        Point startingLoc;
        FloorMap map;
        
        public Kiva(FloorMap defaultMap) {
            map = defaultMap;
        }
        
        public Kiva (FloorMap defaultMap, Point expectedLocation){
            map = defaultMap;
            startingLoc = expectedLocation;
        }
        
        public Point getCurrentLocation(){
            return defaultMap.getInitialKivaLocation();
        }
    }
    public void testSingleArgumentConstructor() {
        // Makes map (arg 1)
        Kiva kiva = new Kiva(defaultMap);
        
        // Check if constructor worked...
        System.out.println(kiva.map);
        
        // Gets kiva starting location
        Point initialLocation = kiva.getCurrentLocation();
        
        // Expected location for kiva to move to
        Point expectedLocation = new Point(2, 4);
        if (sameLocation(initialLocation, expectedLocation)) {
            System.out.println("testSingleArgumentConstructor SUCCESS");
        } else {
            System.out.printf("testSingleArgumentConstructor FAIL: %s != (2,4)!\n", initialLocation);
        }
    }
    
    public void testTwoArgumentConstructor() {
        // Expected location for kiva to move to
        Point expectedLocation = new Point(5, 6);
        
        // Makes map AND starting coords (arg 1, arg2)
        Kiva kiva = new Kiva(defaultMap, expectedLocation);
        
        // Check if constructor worked...
        System.out.println(kiva.map + "" + kiva.startingLoc);
    
        if (sameLocation(kiva.startingLoc, expectedLocation)) {
            System.out.println("testSingleArgumentConstructor SUCCESS");
        } else {
            System.out.printf("testSingleArgumentConstructor FAIL: %s != (5,6)!\n", kiva.startingLoc);
        }
    }
    
    private boolean sameLocation(Point a, Point b) {
        return a.getX() == b.getX() && a.getY() == b.getY();
    }
}
