import edu.duke.Point;

public class KivaTurnLeftTest {
    // Generate Map
    defaultMapGenerator gen = new defaultMapGenerator();
    
    public void turnLeftFromUp() {
        // Make new KivaMoveTest Obj
        KivaMoveTest kivaMoveTest = new KivaMoveTest();
        // Make new Kiva innerObj inside of outerObj KivaMoveTest
        KivaMoveTest.Kiva kiva = kivaMoveTest.new Kiva(gen.defaultMap);
        
        kiva.move(KivaCommand.TURN_LEFT);
        
        kiva.verifyKivaState("testTurnLeftFromUp", 
            kiva, new Point(2, 4), FacingDirection.LEFT, false, false);
    }
    
    public void turnLeftFromLeft() {
        // Make new KivaMoveTest Obj
        KivaMoveTest kivaMoveTest = new KivaMoveTest();
        // Make new Kiva innerObj inside of outerObj KivaMoveTest
        KivaMoveTest.Kiva kiva = kivaMoveTest.new Kiva(gen.defaultMap);
        
        kiva.move(KivaCommand.TURN_LEFT);
        kiva.move(KivaCommand.TURN_LEFT);
        
        kivaMoveTest.verifyKivaState("testTurnLeftFromLeft", 
            kiva, new Point(2, 4), FacingDirection.DOWN, false, false);
    }
    
    public void turnLeftFromDown() {
        // Make new KivaMoveTest Obj
        KivaMoveTest kivaMoveTest = new KivaMoveTest();
        // Make new Kiva innerObj inside of outerObj KivaMoveTest
        KivaMoveTest.Kiva kiva = kivaMoveTest.new Kiva(gen.defaultMap);
        
        kiva.move(KivaCommand.TURN_LEFT);
        kiva.move(KivaCommand.TURN_LEFT);
        kiva.move(KivaCommand.TURN_LEFT);
        
        kivaMoveTest.verifyKivaState("testTurnLeftFromDown", 
            kiva, new Point(2, 4), FacingDirection.RIGHT, false, false);
    }
    
    public void turnLeftFromRight() {
        // Make new KivaMoveTest Obj
        KivaMoveTest kivaMoveTest = new KivaMoveTest();
        // Make new Kiva innerObj inside of outerObj KivaMoveTest
        KivaMoveTest.Kiva kiva = kivaMoveTest.new Kiva(gen.defaultMap);
        
        kiva.move(KivaCommand.TURN_LEFT);
        kiva.move(KivaCommand.TURN_LEFT);
        kiva.move(KivaCommand.TURN_LEFT);
        kiva.move(KivaCommand.TURN_LEFT);
        
        kivaMoveTest.verifyKivaState("testTurnLeftFromRight", 
            kiva, new Point(2, 4), FacingDirection.UP, false, false);
    }
    
}
