import java.util.ArrayList;

public class RemoteControlTest extends RemoteControl{
        
        public void test1(){
            String strInput = "FFFTRF";
            ArrayList<KivaCommand> cmdOutput = convertToKivaCommands(strInput);
            System.out.println("test1 results: " + cmdOutput);
        }
        
        public void test2(){
            String strInput = "B";
            ArrayList<KivaCommand> cmdOutput = convertToKivaCommands(strInput);
            System.out.println("test2 results: " + cmdOutput);
        }
    }
