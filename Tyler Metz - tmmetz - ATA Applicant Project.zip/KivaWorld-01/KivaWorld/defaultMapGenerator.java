/**
 * In RemoteControl, the user can select the map they want,
 * so this is unused and is only used for generating maps on test cases.
 */
public class defaultMapGenerator {
    String defaultLayout = ""
                           + "-------------\n"
                           + "        P   *\n"
                           + "   **       *\n"
                           + "   **       *\n"
                           + "  K       D *\n"
                           + " * * * * * **\n"
                           + "-------------\n";
    String motorLayout = ""
                      + "-----\n"
                      + "|K D|\n"
                      + "| P |\n"
                      + "|* *|\n"
                      + "-----\n";
                      
    FloorMap defaultMap = new FloorMap(defaultLayout);
    FloorMap motorMap = new FloorMap(motorLayout);
}
