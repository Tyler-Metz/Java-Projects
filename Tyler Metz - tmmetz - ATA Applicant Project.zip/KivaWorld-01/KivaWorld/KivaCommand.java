/**
 * Enum is used in RemoteControl and is then passed into the method move() inside the KivaMoveTest.Kiva class.
 *
 */
public enum KivaCommand {
    FORWARD, TURN_LEFT, TURN_RIGHT, TAKE, DROP;
    
    /**
     * Receives KivaCommand and returns it as a char value.
     * @return the char value of the enum.
     */
    public char getDirectionKey() {
        switch(this){
            default:
                return 'D';
            case FORWARD:
                return 'F';
            case TURN_LEFT:
                return 'L';
            case TURN_RIGHT:
                return 'R';
            case TAKE:
                return 'T';
        }
    } 
    
}
